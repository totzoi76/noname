# Tot-Bcrypt : [gagaltotal.github.io] #

![Screen Capture](https://raw.githubusercontent.com/gagaltotal/Tot-Bcrypt/main/tot-bcrypt.png)

#use python3, install package dependencies :

```sh
$ git clone https://github.com/gagaltotal/Tot-Bcrypt
$ cd Tot-Bcrypt
$ sudo pip3 install -r requirements.txt
$ ./tot-bcrypt & python3 tot-bcrypt.py

#Example GNU/Linux :

```sh

=============================   Welcome To Tot-bcrypt       ===========================
=   ████████╗ ██████╗ ████████╗   ██████╗  ██████╗██████╗ ██╗   ██╗██████╗ ████████╗  =
=   ╚══██╔══╝██╔═══██╗╚══██╔══╝   ██╔══██╗██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝  =
=      ██║   ██║   ██║   ██║█████╗██████╔╝██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║     =
=      ██║   ██║   ██║   ██║╚════╝██╔══██╗██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║     =
=      ██║   ╚██████╔╝   ██║      ██████╔╝╚██████╗██║  ██║   ██║   ██║        ██║     =
=      ╚═╝    ╚═════╝    ╚═╝      ╚═════╝  ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝     =
============================= https://gagaltotal.github.io/ ===========================

decode bcrypt nya bro ? ketik (y) untuk melanjutkan decode, key (ctrl+c) tidak melanjutkan decode :  
```

Recode Sumber : [https://github.com/BREAKTEAM/Debcrypt]
